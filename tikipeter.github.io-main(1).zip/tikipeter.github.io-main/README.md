`2.0.02` is the latest and last release of Fen Light.

For the love of God, please don't open any issues for bugs for this release. I need this thing finished with.

Thank you.
